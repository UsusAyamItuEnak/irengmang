<?php
session_start();

// Cek apakah sudah login
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

$username = strtoupper($_SESSION['username']);
$status = strtoupper($_SESSION['status']);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Dashboard</title>
    <link rel="stylesheet" href="dashboard.css">
</head>
<body>
    <div class="header">
        <img src="../GambarTB2.jpg" alt="Foto User" class="user-image">
        <span class="welcome-text">SELAMAT DATANG <?php echo $username; ?> (<?php echo $status; ?>) |</span>
        <a href="logout.php" class="logout-btn">Logout</a>
    </div>

    <div class="content">
        <h2>Ini adalah halaman dashboard Anda.</h2>
        <p>Selamat datang, <?php echo $username; ?>!</p>
    </div>
</body>
</html>
